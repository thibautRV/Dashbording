// server.js
const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const app = express();
const port = 3000;

app.use(express.static('public'));

app.get('/api/data', (req, res) => {
  const data = [];

  fs.createReadStream('public/data/your_data.csv')
    .pipe(csv())
    .on('data', (row) => {
      data.push(row);
    })
    .on('end', () => {
      res.json(data);
    });
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
